"""A relationship matrix plugin for novelibre

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_matrix
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import webbrowser

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_matrix',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from pathlib import Path



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import ttk

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass


class GenericKeys:

    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')


class GenericMouse:

    TOGGLE_STATE = '<Control-Button-1>'


class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')



class MacMouse(GenericMouse):

    TOGGLE_STATE = '<Command-Button-1>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

import platform

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = GenericMouse
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse



class Node(tk.Label):
    marker = '⬛'
    isLocked = False

    def __init__(
            self,
            master,
            colorFalse='white',
            colorTrue='black',
            cnf={},
            **kw
    ):
        self.colorFg = colorTrue
        self.colorBg = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self.config(background=self.colorBg)
        self.config(foreground=self.colorFg)
        self.bind(MOUSE.TOGGLE_STATE, self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_marker()

    def _set_marker(self):
        if self._state:
            self.config(text=self.marker)
        else:
            self.config(text='')

    def _toggle_state(self, event=None):
        if not self.isLocked:
            self.state = not self._state
import textwrap
from tkinter import ttk



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr



class RelationsTable:
    NOTE_WIDTH = 30

    def __init__(self, master, novel, prefs, setHovertip):
        self._novel = novel
        self._prefs = prefs
        self._setHovertip = setHovertip
        self.draw_matrix(master)

    def draw_matrix(self, master):

        def fill_str(text):
            while len(text) < 7:
                text = f' {text} '
            return text

        colorsBackground = (
            (self._prefs['color_bg_00'], self._prefs['color_bg_01']),
            (self._prefs['color_bg_10'], self._prefs['color_bg_11']),
        )
        columns = []
        col = 0
        bgc = col % 2

        tk.Label(
            master.topLeft,
            text=_('Sections'),
        ).pack(fill='x')
        tk.Label(
            master.topLeft,
            bg=colorsBackground[1][1],
            text=' ',
        ).pack(fill='x')

        row = 0
        self._plotlineNodes = {}
        self._characterNodes = {}
        self._locationNodes = {}
        self._itemNodes = {}
        self._sections = []

        for chId in self._novel.tree.get_children(CH_ROOT):
            for scId in self._novel.tree.get_children(chId):
                bgr = row % 2
                if self._novel.sections[scId].scType != 0:
                    continue

                self._sections.append(scId)

                self._characterNodes[scId] = {}
                self._locationNodes[scId] = {}
                self._itemNodes[scId] = {}
                self._plotlineNodes[scId] = {}

                tk.Label(
                    master.rowTitles,
                    text=self._novel.sections[scId].title,
                    bg=colorsBackground[bgr][1],
                    justify='left',
                    anchor='w',
                ).pack(fill='x')
                row += 1
        bgr = row % 2
        tk.Label(
            master.rowTitles,
            text=' ',
            bg=colorsBackground[bgr][1],
        ).pack(fill='x')
        tk.Label(
            master.rowTitles,
            text=_('Sections'),
        ).pack(fill='x')

        if self._novel.plotLines and self._prefs['show_plot_lines']:
            plotlineTitleWindow = ttk.Frame(master.columnTitles)
            plotlineTitleWindow.pack(side='left', fill='both')
            tk.Label(
                plotlineTitleWindow,
                text=_('Plot lines'),
                bg=self._prefs['color_plotline_heading'],
            ).pack(fill='x')
            plotlineTypeColumn = ttk.Frame(master.display)
            plotlineTypeColumn.pack(side='left', fill='both')
            plotlineColumn = ttk.Frame(plotlineTypeColumn)
            plotlineColumn.pack(fill='both')
            for plId in self._novel.tree.get_children(PL_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                plotlineTitle = fill_str(self._novel.plotLines[plId].shortName)
                hoverText = self._novel.plotLines[plId].title
                pl = tk.Label(
                    plotlineTitleWindow,
                    text=plotlineTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                )
                pl.pack(side='left', fill='x', expand=True)
                self._setHovertip(pl, hoverText)
                row += 1

                columns.append(tk.Frame(plotlineColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._plotlineNodes:
                    bgr = row % 2
                    node = Node(
                        columns[col],
                        colorFalse=colorsBackground[bgr][bgc],
                        colorTrue=self._prefs['color_plotline_node']
                    )
                    node.pack(fill='x', expand=True)
                    self._plotlineNodes[scId][plId] = node
                    if self._novel.sections[scId].plotlineNotes.get(
                        plId,
                        None
                    ):
                        plNotes = textwrap.wrap(
                            self._novel.sections[scId].plotlineNotes[plId],
                            width=self.NOTE_WIDTH,
                        )
                        self._setHovertip(
                            node,
                            '\n'.join(plNotes),
                        )
                    row += 1
                bgr = row % 2
                pl = tk.Label(
                    columns[col],
                    text=plotlineTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w'
                )
                pl.pack(fill='x', expand=True)
                self._setHovertip(pl, hoverText)
                col += 1
            tk.Label(
                plotlineTypeColumn,
                text=_('Plot lines'),
                bg=self._prefs['color_plotline_heading'],
            ).pack(fill='x')

        if self._novel.characters and self._prefs['show_characters']:
            characterTypeColumn = ttk.Frame(master.display)
            characterTypeColumn.pack(side='left', fill='both')
            characterColumn = ttk.Frame(characterTypeColumn)
            characterColumn.pack(fill='both')
            characterTitleWindow = ttk.Frame(master.columnTitles)
            characterTitleWindow.pack(side='left', fill='both')
            tk.Label(
                characterTitleWindow,
                text=_('Characters'),
                bg=self._prefs['color_character_heading'],
            ).pack(fill='x')
            for crId in self._novel.tree.get_children(CR_ROOT):
                if (
                    self._prefs['major_characters_only']
                    and not self._novel.characters[crId].isMajor
                ):
                    continue

                row = 1
                bgr = row % 2
                bgc = col % 2
                characterTitle = fill_str(self._novel.characters[crId].title)
                hoverText = self._novel.characters[crId].fullName
                if self._novel.characters[crId].aka:
                    hoverText = (
                        f'{hoverText}\n'
                        f'({self._novel.characters[crId].aka})'
                    )
                cr = tk.Label(
                    characterTitleWindow,
                    text=characterTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                )
                cr.pack(side='left', fill='x', expand=True)
                self._setHovertip(cr, hoverText)
                row += 1

                columns.append(tk.Frame(characterColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._characterNodes:
                    bgr = row % 2
                    node = Node(
                        columns[col],
                        colorFalse=colorsBackground[bgr][bgc],
                        colorTrue=self._prefs['color_character_node']
                    )
                    node.pack(fill='x', expand=True)
                    self._characterNodes[scId][crId] = node
                    row += 1
                bgr = row % 2
                cr = tk.Label(
                    columns[col],
                    text=characterTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                )
                cr.pack(fill='x', expand=True)
                self._setHovertip(cr, hoverText)
                col += 1
            tk.Label(
                characterTypeColumn,
                text=_('Characters'),
                bg=self._prefs['color_character_heading'],
            ).pack(fill='x')

        if self._novel.locations and self._prefs['show_locations']:
            locationTypeColumn = ttk.Frame(master.display)
            locationTypeColumn.pack(side='left', fill='both')
            locationColumn = ttk.Frame(locationTypeColumn)
            locationColumn.pack(fill='both')
            locationTitleWindow = ttk.Frame(master.columnTitles)
            locationTitleWindow.pack(side='left', fill='both')
            tk.Label(
                locationTitleWindow,
                text=_('Locations'),
                bg=self._prefs['color_location_heading'],
            ).pack(fill='x')
            for lcId in self._novel.tree.get_children(LC_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                locationTitle = fill_str(self._novel.locations[lcId].title)
                tk.Label(
                    locationTitleWindow,
                    text=locationTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(locationColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._locationNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._prefs['color_location_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._locationNodes[scId][lcId] = node
                    row += 1
                bgr = row % 2
                tk.Label(
                    columns[col],
                    text=locationTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                ).pack(fill='x', expand=True)
                col += 1
            tk.Label(
                locationTypeColumn,
                text=_('Locations'),
                bg=self._prefs['color_location_heading'],
            ).pack(fill='x')

        if self._novel.items and self._prefs['show_items']:
            itemTypeColumn = ttk.Frame(master.display)
            itemTypeColumn.pack(side='left', fill='both')
            itemColumn = ttk.Frame(itemTypeColumn)
            itemColumn.pack(fill='both')
            itemTitleWindow = ttk.Frame(master.columnTitles)
            itemTitleWindow.pack(side='left', fill='both')
            tk.Label(
                itemTitleWindow,
                text=_('Items'),
                bg=self._prefs['color_item_heading'],
            ).pack(fill='x')
            for itId in self._novel.tree.get_children(IT_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                itemTitle = fill_str(self._novel.items[itId].title)
                tk.Label(
                    itemTitleWindow,
                    text=itemTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(itemColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._itemNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._prefs['color_item_node'],
                    )
                    node.pack(fill='x', expand=True)
                    self._itemNodes[scId][itId] = node
                    row += 1
                bgr = row % 2
                tk.Label(
                    columns[col],
                    text=itemTitle,
                    bg=colorsBackground[bgr][bgc],
                    justify='left',
                    anchor='w',
                ).pack(fill='x', expand=True)
                col += 1
            tk.Label(
                itemTypeColumn,
                text=_('Items'),
                bg=self._prefs['color_item_heading'],
            ).pack(fill='x')

    def set_nodes(self):
        for scId in self._sections:

            if self._prefs['show_plot_lines']:
                for plId in self._novel.plotLines:
                    self._plotlineNodes[scId][plId].state = (
                        plId in self._novel.sections[scId].scPlotLines)

            if self._prefs['show_characters']:
                for crId in self._novel.characters:
                    if (
                        self._prefs['major_characters_only']
                        and not self._novel.characters[crId].isMajor
                    ):
                        continue

                    self._characterNodes[scId][crId].state = (
                        crId in self._novel.sections[scId].characters)

            if self._prefs['show_locations']:
                for lcId in self._novel.locations:
                    self._locationNodes[scId][lcId].state = (
                        lcId in self._novel.sections[scId].locations)

            if self._prefs['show_items']:
                for itId in self._novel.items:
                    self._itemNodes[scId][itId].state = (
                        itId in self._novel.sections[scId].items)

    def get_nodes(self):

        def get_plot_line_node(plId, scId):
            plotlineSections = self._novel.plotLines[plId].sections
            if self._plotlineNodes[scId][plId].state:
                if not plId in self._novel.sections[scId].scPlotLines:
                    self._novel.sections[scId].scPlotLines.append(plId)
                if not scId in plotlineSections:
                    plotlineSections.append(scId)
            else:
                if plId in self._novel.sections[scId].scPlotLines:
                    self._novel.sections[scId].scPlotLines.remove(plId)
                if scId in plotlineSections:
                    plotlineSections.remove(scId)
                for ppId in list(self._novel.sections[scId].scPlotPoints):
                    if (
                        self._novel.sections[scId].scPlotPoints[ppId]
                        == plId
                    ):
                        del self._novel.sections[scId].scPlotPoints[ppId]
                        self._novel.plotPoints[ppId].sectionAssoc = None
            self._novel.plotLines[plId].sections = plotlineSections

        def get_character_node(crId, scCharacters):
            if (
                self._prefs['major_characters_only']
                and not self._novel.characters[crId].isMajor
            ):
                return

            if self._characterNodes[scId][crId].state:
                if not crId in scCharacters:
                    scCharacters.append(crId)
            elif crId in scCharacters:
                scCharacters.remove(crId)

        for scId in self._sections:

            if self._prefs['show_plot_lines']:
                for plId in self._novel.plotLines:
                    get_plot_line_node(plId, scId)

            if self._prefs['show_characters']:
                scCharacters = self._novel.sections[scId].characters
                for crId in self._novel.characters:
                    get_character_node(crId, scCharacters)
                self._novel.sections[scId].characters = scCharacters

            if self._prefs['show_locations']:
                scLocations = self._novel.sections[scId].locations
                for lcId in self._novel.locations:
                    if self._locationNodes[scId][lcId].state:
                        if not lcId in scLocations:
                            scLocations.append(lcId)
                    elif lcId in scLocations:
                        scLocations.remove(lcId)
                self._novel.sections[scId].locations = scLocations

            if self._prefs['show_items']:
                scItems = self._novel.sections[scId].items
                for itId in self._novel.items:
                    if self._itemNodes[scId][itId].state:
                        if not itId in scItems:
                            scItems.append(itId)
                    elif itId in scItems:
                        scItems.remove(itId)
                self._novel.sections[scId].items = scItems

from tkinter import ttk



class TableFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.xview)
        scrollX.pack(fill='x', side='bottom', expand=False)

        leftColFrame = ttk.Frame(self)
        leftColFrame.pack(side='left', fill='both', expand=False)

        self.topLeft = ttk.Frame(leftColFrame)
        self.topLeft.pack(anchor='w', fill='x', expand=False)

        rowTitlesFrame = ttk.Frame(leftColFrame)
        rowTitlesFrame.pack(fill='both', expand=True)
        self._rowTitlesCanvas = tk.Canvas(
            rowTitlesFrame,
            bd=0,
            highlightthickness=0,
        )
        self._rowTitlesCanvas.configure(yscrollcommand=scrollY.set)
        self._rowTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._rowTitlesCanvas.xview_moveto(0)
        self._rowTitlesCanvas.yview_moveto(0)

        self.rowTitles = ttk.Frame(self._rowTitlesCanvas)
        self._rowTitlesCanvas.create_window(
            0,
            0,
            window=self.rowTitles,
            anchor='nw',
            tags='self.rowTitles',
        )

        def _configure_rowTitles(event):
            size = (
                self.rowTitles.winfo_reqwidth(),
                self.rowTitles.winfo_reqheight()
            )
            self._rowTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if (
                self.rowTitles.winfo_reqwidth()
                != self._rowTitlesCanvas.winfo_width()
            ):
                self._rowTitlesCanvas.config(
                    width=self.rowTitles.winfo_reqwidth()
                )

        self.rowTitles.bind('<Configure>', _configure_rowTitles)

        rightColFrame = ttk.Frame(self)
        rightColFrame.pack(side='left', anchor='nw', fill='both', expand=True)

        columnTitlesFrame = ttk.Frame(rightColFrame)
        columnTitlesFrame.pack(fill='x', anchor='nw', expand=False)
        self._columnTitlesCanvas = tk.Canvas(
            columnTitlesFrame,
            bd=0,
            highlightthickness=0,
        )
        self._columnTitlesCanvas.configure(xscrollcommand=scrollX.set)
        self._columnTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._columnTitlesCanvas.xview_moveto(0)
        self._columnTitlesCanvas.yview_moveto(0)

        self.columnTitles = ttk.Frame(self._columnTitlesCanvas)
        self._columnTitlesCanvas.create_window(
            0,
            0,
            window=self.columnTitles,
            anchor='nw',
            tags='self.columnTitles',
        )

        def _configure_columnTitles(event):
            size = (
                self.columnTitles.winfo_reqwidth(),
                self.columnTitles.winfo_reqheight()
            )
            self._columnTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if (
                self.columnTitles.winfo_reqwidth()
                != self._columnTitlesCanvas.winfo_width()
            ):
                self._columnTitlesCanvas.config(
                    width=self.columnTitles.winfo_reqwidth()
                )
            if (
                self.columnTitles.winfo_reqheight()
                != self._columnTitlesCanvas.winfo_height()
            ):
                self._columnTitlesCanvas.config(
                    height=self.columnTitles.winfo_reqheight()
                )

        self.columnTitles.bind('<Configure>', _configure_columnTitles)

        displayFrame = ttk.Frame(rightColFrame)
        displayFrame.pack(fill='both', expand=True)
        self._displayCanvas = tk.Canvas(
            displayFrame,
            bd=0,
            highlightthickness=0,
        )
        self._displayCanvas.configure(xscrollcommand=scrollX.set)
        self._displayCanvas.configure(yscrollcommand=scrollY.set)
        self._displayCanvas.pack(side='left', fill='both', expand=True)
        self._displayCanvas.xview_moveto(0)
        self._displayCanvas.yview_moveto(0)

        self.display = ttk.Frame(self._displayCanvas)
        self._displayCanvas.create_window(
            0,
            0,
            window=self.display,
            anchor='nw',
            tags='self.display',
        )

        def _configure_display(event):
            size = (
                self.display.winfo_reqwidth(),
                self.display.winfo_reqheight()
            )
            self._displayCanvas.config(scrollregion="0 0 %s %s" % size)
            if (
                self.display.winfo_reqwidth()
                != self._displayCanvas.winfo_width()
            ):
                self._displayCanvas.config(width=self.display.winfo_reqwidth())

        self.display.bind('<Configure>', _configure_display)
        self.bind('<Enter>', self._bind_mousewheel)
        self.bind('<Leave>', self._unbind_mousewheel)

    def destroy(self):
        self.display.unbind('<Configure>')
        self._unbind_mousewheel()
        super().destroy()

    def vertical_scroll(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.yview_scroll(-1, 'units')
            elif event.num == 5:
                self.yview_scroll(1, 'units')

    def horizontal_scroll(self, event):
        if platform.system() == 'Windows':
            self.xview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif platform.system() == 'Darwin':
            self.xview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.xview_scroll(-1, 'units')
            elif event.num == 5:
                self.xview_scroll(1, 'units')

    def xview(self, *args):
        self._columnTitlesCanvas.xview(*args)
        self._displayCanvas.xview(*args)

    def xview_scroll(self, *args):
        if not self._displayCanvas.xview() == (0.0, 1.0):
            self._columnTitlesCanvas.xview_scroll(*args)
            self._displayCanvas.xview_scroll(*args)

    def yview(self, *args):
        self._rowTitlesCanvas.yview(*args)
        self._displayCanvas.yview(*args)

    def yview_scroll(self, *args):
        if not self._displayCanvas.yview() == (0.0, 1.0):
            self._rowTitlesCanvas.yview_scroll(*args)
            self._displayCanvas.yview_scroll(*args)

    def _bind_mousewheel(self, event=None):
        if platform.system() in ('Linux', 'FreeBSD'):
            self._rowTitlesCanvas.bind_all(
                '<Button-4>',
                self.vertical_scroll
            )
            self._rowTitlesCanvas.bind_all(
                '<Button-5>',
                self.vertical_scroll
            )
            self._displayCanvas.bind_all(
                '<Button-4>',
                self.vertical_scroll
            )
            self._displayCanvas.bind_all(
                '<Button-5>',
                self.vertical_scroll
            )

            self._rowTitlesCanvas.bind_all(
                '<Shift-Button-4>',
                self.horizontal_scroll
            )
            self._rowTitlesCanvas.bind_all(
                '<Shift-Button-5>',
                self.horizontal_scroll
            )
            self._displayCanvas.bind_all(
                '<Shift-Button-4>',
                self.horizontal_scroll
            )
            self._displayCanvas.bind_all(
                '<Shift-Button-5>',
                self.horizontal_scroll
            )
        else:
            self._rowTitlesCanvas.bind_all(
                '<MouseWheel>',
                self.vertical_scroll
            )
            self._displayCanvas.bind_all(
                '<MouseWheel>',
                self.vertical_scroll
            )

            self._rowTitlesCanvas.bind_all(
                '<Shift-MouseWheel>',
                self.horizontal_scroll
            )
            self._displayCanvas.bind_all(
                '<Shift-MouseWheel>',
                self.horizontal_scroll
            )

    def _unbind_mousewheel(self, event=None):
        if platform.system() in ('Linux', 'FreeBSD'):
            self._rowTitlesCanvas.unbind_all('<Button-4>')
            self._rowTitlesCanvas.unbind_all('<Button-5>')
            self._displayCanvas.unbind_all('<Button-4>')
            self._displayCanvas.unbind_all('<Button-5>')

            self._rowTitlesCanvas.unbind_all('<Shift-Button-4>')
            self._rowTitlesCanvas.unbind_all('<Shift-Button-5>')
            self._displayCanvas.unbind_all('<Shift-Button-4>')
            self._displayCanvas.unbind_all('<Shift-Button-5>')
        else:
            self._rowTitlesCanvas.unbind_all('<MouseWheel>')
            self._displayCanvas.unbind_all('<MouseWheel>')

            self._rowTitlesCanvas.unbind_all('<Shift-MouseWheel>')
            self._displayCanvas.unbind_all('<Shift-MouseWheel>')



class MatrixView(tk.Toplevel, Observer, SubController):

    def __init__(self, model, controller, prefs):
        tk.Toplevel.__init__(self)

        self._mdl = model
        self.prefs = prefs
        self.isOpen = True
        if controller.isLocked:
            self.lock()

        self.geometry(self.prefs['window_geometry'])
        self.lift()
        self.focus()

        self._mdl.add_observer(self)

        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill='both', expand=True)
        self.tableFrame = TableFrame(self.mainWindow)

        if self._mdl.novel is not None:
            self._relationsTable = RelationsTable(
                self.tableFrame,
                self._mdl.novel,
                self.prefs,
                self._mdl.nvService.new_hovertip,
            )
            self._relationsTable.set_nodes()
        self.tableFrame.pack(fill='both', expand=True, padx=2, pady=2)

        self._skipUpdate = False
        self.bind(MOUSE.TOGGLE_STATE, self._on_element_change)

        self._showPlotlines = tk.BooleanVar(
            value=self.prefs['show_plot_lines'],
        )
        ttk.Checkbutton(
            self,
            text=_('Plot lines'),
            variable=self._showPlotlines,
            onvalue=True,
            offvalue=False,
            command=self._change_show_plot_lines,
        ).pack(side='left', padx=5, pady=5)

        self._showCharacters = tk.BooleanVar(
            value=self.prefs['show_characters'],
        )
        ttk.Checkbutton(
            self,
            text=_('Characters'),
            variable=self._showCharacters,
            onvalue=True,
            offvalue=False,
            command=self._change_show_characters,
        ).pack(side='left', padx=5, pady=5)

        self._showLocations = tk.BooleanVar(
            value=self.prefs['show_locations'],
        )
        ttk.Checkbutton(
            self,
            text=_('Locations'),
            variable=self._showLocations,
            onvalue=True,
            offvalue=False,
            command=self._change_show_locations,
        ).pack(side='left', padx=5, pady=5)

        self._showItems = tk.BooleanVar(
            value=self.prefs['show_items'],
        )
        ttk.Checkbutton(
            self,
            text=_('Items'),
            variable=self._showItems,
            onvalue=True,
            offvalue=False,
            command=self._change_show_items,
        ).pack(side='left', padx=5, pady=5)

        self._majorCharactersOnly = tk.BooleanVar(
            value=self.prefs['major_characters_only'],
        )
        ttk.Checkbutton(
            self,
            text=_('Major characters only'),
            variable=self._majorCharactersOnly,
            onvalue=True,
            offvalue=False,
            command=self._change_major_characters_only,
        ).pack(side='left', padx=5, pady=5)

        ttk.Button(
            self,
            text=_('Close'),
            command=self.on_quit,
        ).pack(side='right', padx=5, pady=5)

    def lock(self):
        Node.isLocked = True

    def refresh(self):
        if not self.isOpen:
            return

        if self._skipUpdate:
            return

        self.tableFrame.pack_forget()
        self.tableFrame.destroy()
        self.tableFrame = TableFrame(self.mainWindow)
        self.tableFrame.pack(fill='both', expand=True, padx=2, pady=2)
        self._relationsTable.draw_matrix(self.tableFrame)
        self._relationsTable.set_nodes()

    def on_quit(self, event=None):
        self.isOpen = False
        self.prefs['window_geometry'] = self.winfo_geometry()
        self.tableFrame.destroy()
        self._mdl.delete_observer(self)
        self.destroy()

    def unlock(self):
        Node.isLocked = False

    def _change_major_characters_only(self):
        self.prefs['major_characters_only'] = (
            self._majorCharactersOnly.get()
        )
        if self.prefs['show_characters']:
            self.refresh()

    def _change_show_characters(self):
        self.prefs['show_characters'] = (
            self._showCharacters.get()
        )
        self.refresh()

    def _change_show_items(self):
        self.prefs['show_items'] = (
            self._showItems.get()
        )
        self.refresh()

    def _change_show_locations(self):
        self.prefs['show_locations'] = (
            self._showLocations.get()
        )
        self.refresh()

    def _change_show_plot_lines(self):
        self.prefs['show_plot_lines'] = (
            self._showPlotlines.get()
        )
        self.refresh()

    def _on_element_change(self, event=None):
        self._skipUpdate = True
        self._relationsTable.get_nodes()
        self._skipUpdate = False



class MatrixService(SubController):
    INI_FILENAME = 'matrix.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        window_geometry='600x800',
        color_bg_00='gray80',
        color_bg_01='gray85',
        color_bg_10='gray95',
        color_bg_11='white',
        color_plotline_heading='deepSkyBlue',
        color_plotline_node='deepSkyBlue3',
        color_character_heading='goldenrod1',
        color_character_node='goldenrod3',
        color_location_heading='coral1',
        color_location_node='coral3',
        color_item_heading='aquamarine1',
        color_item_node='aquamarine3',
    )
    OPTIONS = dict(
        show_plot_lines=True,
        show_characters=True,
        show_locations=False,
        show_items=True,
        major_characters_only=False,
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._matrixViewer = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

    def lock(self):
        if self._matrixViewer:
            self._matrixViewer.lock()

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]
        self.configuration.write()

    def unlock(self):
        if self._matrixViewer:
            self._matrixViewer.unlock()

    def start_viewer(self, windowTitle):
        if not self._mdl.prjFile:
            return

        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                if self._matrixViewer.state() == 'iconic':
                    self._matrixViewer.state('normal')
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        self._matrixViewer = MatrixView(
            self._mdl,
            self._ctrl,
            self.prefs,
        )
        self._matrixViewer.title(f'{self._mdl.novel.title} - {windowTitle}')
        set_icon(self._matrixViewer, icon='matrix', default=False)



class Plugin(PluginBase):
    VERSION = '5.7.0'
    API_VERSION = '5.50'
    DESCRIPTION = 'A section relationship table'
    URL = 'https://github.com/peter88213/nv_matrix'
    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_matrix/'

    FEATURE = _('Matrix')

    def install(self, model, view, controller):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            model -- Reference to the model instance.
            view -- Reference to the main view instance.
            controller -- Reference to the main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.matrixService = MatrixService(model, view, controller)
        self._icon = self._get_icon('matrix.png')


        label = self.FEATURE
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.start_viewer,
            state='disabled',
        )
        self._ui.toolsMenu.disableOnClose.append(label)

        label = _('Matrix plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.open_help,
        )

        self._ui.toolbar.add_separator(),

        self._ui.toolbar.new_button(
            text=_('Matrix'),
            image=self._icon,
            command=self.start_viewer,
            disableOnLock=False,
        ).pack(side='left')

    def lock(self):
        self.matrixService.lock()

    def on_close(self):
        self.matrixService.on_close()

    def on_quit(self):
        self.matrixService.on_quit()

    def open_help(self):
        webbrowser.open(self.HELP_URL)

    def start_viewer(self):
        self.matrixService.start_viewer(self.FEATURE)

    def unlock(self):
        self.matrixService.unlock()

