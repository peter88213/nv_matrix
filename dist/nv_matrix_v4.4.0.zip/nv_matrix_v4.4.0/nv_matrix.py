"""A relationship matrix plugin for novelibre

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_matrix
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
import webbrowser

import os
import sys
import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass
from tkinter import ttk


class MatrixButton:

    def __init__(self, view, text, icon, command):
        self._ui = view
        self._toolbarButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=text,
            image=icon,
            command=command
            )
        self._toolbarButton.pack(side='left')
        self._toolbarButton.image = icon

    def disable(self):
        self._toolbarButton.config(state='disabled')

    def enable(self):
        self._toolbarButton.config(state='normal')
import gettext
import locale

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_matrix', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

import platform
from tkinter import ttk



class Node(tk.Label):
    marker = '⬛'
    isLocked = False

    def __init__(self, master, colorFalse='white', colorTrue='black', cnf={}, **kw):
        self.colorFg = colorTrue
        self.colorBg = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self.config(background=self.colorBg)
        self.config(foreground=self.colorFg)
        self.bind('<Control-Button-1>', self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_marker()

    def _set_marker(self):
        if self._state:
            self.config(text=self.marker)
        else:
            self.config(text='')

    def _toggle_state(self, event=None):
        if not self.isLocked:
            self.state = not self._state
from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


locale.setlocale(locale.LC_TIME, "")
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



class RelationsTable:

    def __init__(self, master, novel, **kwargs):
        self._novel = novel
        self._kwargs = kwargs
        self.draw_matrix(master)

    def draw_matrix(self, master):

        def fill_str(text):
            while len(text) < 7:
                text = f' {text} '
            return text

        colorsBackground = ((self._kwargs['color_bg_00'], self._kwargs['color_bg_01']),
                            (self._kwargs['color_bg_10'], self._kwargs['color_bg_11']))
        columns = []
        col = 0
        bgc = col % 2

        tk.Label(master.topLeft, text=_('Sections')).pack(fill='x')
        tk.Label(master.topLeft, bg=colorsBackground[1][1], text=' ').pack(fill='x')

        row = 0
        self._plotlineNodes = {}
        self._characterNodes = {}
        self._locationNodes = {}
        self._itemNodes = {}
        for chId in self._novel.tree.get_children(CH_ROOT):
            if self._novel.chapters[chId].chType == 0:
                for scId in self._novel.tree.get_children(chId):
                    bgr = row % 2
                    if self._novel.sections[scId].scType != 0:
                        continue

                    self._characterNodes[scId] = {}
                    self._locationNodes[scId] = {}
                    self._itemNodes[scId] = {}
                    self._plotlineNodes[scId] = {}

                    tk.Label(master.rowTitles,
                             text=self._novel.sections[scId].title,
                             bg=colorsBackground[bgr][1],
                             justify='left',
                             anchor='w'
                             ).pack(fill='x')
                    row += 1
        bgr = row % 2
        tk.Label(master.rowTitles,
                         text=' ',
                         bg=colorsBackground[bgr][1],
                         ).pack(fill='x')
        tk.Label(master.rowTitles,
                         text=_('Sections'),
                         ).pack(fill='x')

        if self._novel.plotLines:
            plotlineTitleWindow = tk.Frame(master.columnTitles)
            plotlineTitleWindow.pack(side='left', fill='both')
            tk.Label(plotlineTitleWindow, text=_('Plot lines'), bg=self._kwargs['color_arc_heading']).pack(fill='x')
            plotlineTypeColumn = tk.Frame(master.display)
            plotlineTypeColumn.pack(side='left', fill='both')
            plotlineColumn = tk.Frame(plotlineTypeColumn)
            plotlineColumn.pack(fill='both')
            for plId in self._novel.tree.get_children(PL_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                plotlineTitle = fill_str(self._novel.plotLines[plId].shortName)
                tk.Label(plotlineTitleWindow,
                         text=plotlineTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(plotlineColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._plotlineNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_arc_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._plotlineNodes[scId][plId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=plotlineTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(plotlineTypeColumn, text=_('Plot lines'), bg=self._kwargs['color_arc_heading']).pack(fill='x')

        if self._novel.characters:
            characterTypeColumn = tk.Frame(master.display)
            characterTypeColumn.pack(side='left', fill='both')
            characterColumn = tk.Frame(characterTypeColumn)
            characterColumn.pack(fill='both')
            characterTitleWindow = tk.Frame(master.columnTitles)
            characterTitleWindow.pack(side='left', fill='both')
            tk.Label(characterTitleWindow, text=_('Characters'), bg=self._kwargs['color_character_heading']).pack(fill='x')
            for crId in self._novel.tree.get_children(CR_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                characterTitle = fill_str(self._novel.characters[crId].title)
                tk.Label(characterTitleWindow,
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(characterColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._characterNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_character_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._characterNodes[scId][crId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(characterTypeColumn, text=_('Characters'), bg=self._kwargs['color_character_heading']).pack(fill='x')

        if self._novel.locations:
            locationTypeColumn = tk.Frame(master.display)
            locationTypeColumn.pack(side='left', fill='both')
            locationColumn = tk.Frame(locationTypeColumn)
            locationColumn.pack(fill='both')
            locationTitleWindow = tk.Frame(master.columnTitles)
            locationTitleWindow.pack(side='left', fill='both')
            tk.Label(locationTitleWindow, text=_('Locations'), bg=self._kwargs['color_location_heading']).pack(fill='x')
            for lcId in self._novel.tree.get_children(LC_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                locationTitle = fill_str(self._novel.locations[lcId].title)
                tk.Label(locationTitleWindow,
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(locationColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._locationNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_location_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._locationNodes[scId][lcId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(locationTypeColumn, text=_('Locations'), bg=self._kwargs['color_location_heading']).pack(fill='x')

        if self._novel.items:
            itemTypeColumn = tk.Frame(master.display)
            itemTypeColumn.pack(side='left', fill='both')
            itemColumn = tk.Frame(itemTypeColumn)
            itemColumn.pack(fill='both')
            itemTitleWindow = tk.Frame(master.columnTitles)
            itemTitleWindow.pack(side='left', fill='both')
            tk.Label(itemTitleWindow, text=_('Items'), bg=self._kwargs['color_item_heading']).pack(fill='x')
            for itId in self._novel.tree.get_children(IT_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                itemTitle = fill_str(self._novel.items[itId].title)
                tk.Label(itemTitleWindow,
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(itemColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._itemNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_item_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._itemNodes[scId][itId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(itemTypeColumn, text=_('Items'), bg=self._kwargs['color_item_heading']).pack(fill='x')

    def set_nodes(self):
        for scId in self._plotlineNodes:

            for plId in self._novel.plotLines:
                self._plotlineNodes[scId][plId].state = (plId in self._novel.sections[scId].scPlotLines)

            for crId in self._novel.characters:
                self._characterNodes[scId][crId].state = (crId in self._novel.sections[scId].characters)

            for lcId in self._novel.locations:
                self._locationNodes[scId][lcId].state = (lcId in self._novel.sections[scId].locations)

            for itId in self._novel.items:
                self._itemNodes[scId][itId].state = (itId in self._novel.sections[scId].items)

    def get_nodes(self):
        for scId in self._plotlineNodes:

            self._novel.sections[scId].scPlotLines = []
            for plId in self._novel.plotLines:
                plotlineSections = self._novel.plotLines[plId].sections
                if self._plotlineNodes[scId][plId].state:
                    self._novel.sections[scId].scPlotLines.append(plId)
                    if not scId in plotlineSections:
                        plotlineSections.append(scId)
                else:
                    if scId in plotlineSections:
                        plotlineSections.remove(scId)
                    for ppId in list(self._novel.sections[scId].scPlotPoints):
                        if self._novel.sections[scId].scPlotPoints[ppId] == plId:
                            del self._novel.sections[scId].scPlotPoints[ppId]
                            self._novel.plotPoints[ppId].sectionAssoc = None
                self._novel.plotLines[plId].sections = plotlineSections

            scCharacters = self._novel.sections[scId].characters
            for crId in self._novel.characters:
                if self._characterNodes[scId][crId].state:
                    if not crId in scCharacters:
                        scCharacters.append(crId)
                elif crId in scCharacters:
                    scCharacters.remove(crId)
            self._novel.sections[scId].characters = scCharacters

            scLocations = self._novel.sections[scId].locations
            for lcId in self._novel.locations:
                if self._locationNodes[scId][lcId].state:
                    if not lcId in scLocations:
                        scLocations.append(lcId)
                elif lcId in scLocations:
                    scLocations.remove(lcId)
            self._novel.sections[scId].locations = scLocations

            scItems = self._novel.sections[scId].items
            for itId in self._novel.items:
                if self._itemNodes[scId][itId].state:
                    if itId in scItems:
                        scItems.append(itId)
                elif itId in scItems:
                    scItems.remove(itId)

            self._novel.sections[scId].items = scItems

from tkinter import ttk



class TableFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.xview)
        scrollX.pack(fill='x', side='bottom', expand=False)

        leftColFrame = ttk.Frame(self)
        leftColFrame.pack(side='left', fill='both', expand=False)

        self.topLeft = ttk.Frame(leftColFrame)
        self.topLeft.pack(anchor='w', fill='x', expand=False)

        rowTitlesFrame = ttk.Frame(leftColFrame)
        rowTitlesFrame.pack(fill='both', expand=True)
        self._rowTitlesCanvas = tk.Canvas(rowTitlesFrame, bd=0, highlightthickness=0)
        self._rowTitlesCanvas.configure(yscrollcommand=scrollY.set)
        self._rowTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._rowTitlesCanvas.xview_moveto(0)
        self._rowTitlesCanvas.yview_moveto(0)

        self.rowTitles = ttk.Frame(self._rowTitlesCanvas)
        self._rowTitlesCanvas.create_window(0, 0, window=self.rowTitles, anchor='nw', tags="self.rowTitles")

        def _configure_rowTitles(event):
            size = (self.rowTitles.winfo_reqwidth(), self.rowTitles.winfo_reqheight())
            self._rowTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if self.rowTitles.winfo_reqwidth() != self._rowTitlesCanvas.winfo_width():
                self._rowTitlesCanvas.config(width=self.rowTitles.winfo_reqwidth())

        self.rowTitles.bind('<Configure>', _configure_rowTitles)

        rightColFrame = ttk.Frame(self)
        rightColFrame.pack(side='left', anchor='nw', fill='both', expand=True)

        columnTitlesFrame = ttk.Frame(rightColFrame)
        columnTitlesFrame.pack(fill='x', anchor='nw', expand=False)
        self._columnTitlesCanvas = tk.Canvas(columnTitlesFrame, bd=0, highlightthickness=0)
        self._columnTitlesCanvas.configure(xscrollcommand=scrollX.set)
        self._columnTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._columnTitlesCanvas.xview_moveto(0)
        self._columnTitlesCanvas.yview_moveto(0)

        self.columnTitles = ttk.Frame(self._columnTitlesCanvas)
        self._columnTitlesCanvas.create_window(0, 0, window=self.columnTitles, anchor='nw', tags="self.columnTitles")

        def _configure_columnTitles(event):
            size = (self.columnTitles.winfo_reqwidth(), self.columnTitles.winfo_reqheight())
            self._columnTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if self.columnTitles.winfo_reqwidth() != self._columnTitlesCanvas.winfo_width():
                self._columnTitlesCanvas.config(width=self.columnTitles.winfo_reqwidth())
            if self.columnTitles.winfo_reqheight() != self._columnTitlesCanvas.winfo_height():
                self._columnTitlesCanvas.config(height=self.columnTitles.winfo_reqheight())

        self.columnTitles.bind('<Configure>', _configure_columnTitles)

        displayFrame = ttk.Frame(rightColFrame)
        displayFrame.pack(fill='both', expand=True)
        self._displayCanvas = tk.Canvas(displayFrame, bd=0, highlightthickness=0)
        self._displayCanvas.configure(xscrollcommand=scrollX.set)
        self._displayCanvas.configure(yscrollcommand=scrollY.set)
        self._displayCanvas.pack(side='left', fill='both', expand=True)
        self._displayCanvas.xview_moveto(0)
        self._displayCanvas.yview_moveto(0)

        self.display = ttk.Frame(self._displayCanvas)
        self._displayCanvas.create_window(0, 0, window=self.display, anchor='nw', tags="self.display")

        def _configure_display(event):
            size = (self.display.winfo_reqwidth(), self.display.winfo_reqheight())
            self._displayCanvas.config(scrollregion="0 0 %s %s" % size)
            if self.display.winfo_reqwidth() != self._displayCanvas.winfo_width():
                self._displayCanvas.config(width=self.display.winfo_reqwidth())

        self.display.bind('<Configure>', _configure_display)
        self.bind('<Enter>', self._bind_mousewheel)
        self.bind('<Leave>', self._unbind_mousewheel)

    def destroy(self):
        self.display.unbind('<Configure>')
        self._unbind_mousewheel()
        super().destroy()

    def on_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.yview_scroll(-1, "units")
            elif event.num == 5:
                self.yview_scroll(1, "units")

    def on_shift_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.xview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.xview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.xview_scroll(-1, "units")
            elif event.num == 5:
                self.xview_scroll(1, "units")

    def xview(self, *args):
        self._columnTitlesCanvas.xview(*args)
        self._displayCanvas.xview(*args)

    def xview_scroll(self, *args):
        if not self._displayCanvas.xview() == (0.0, 1.0):
            self._columnTitlesCanvas.xview_scroll(*args)
            self._displayCanvas.xview_scroll(*args)

    def yview(self, *args):
        self._rowTitlesCanvas.yview(*args)
        self._displayCanvas.yview(*args)

    def yview_scroll(self, *args):
        if not self._displayCanvas.yview() == (0.0, 1.0):
            self._rowTitlesCanvas.yview_scroll(*args)
            self._displayCanvas.yview_scroll(*args)

    def _bind_mousewheel(self, event=None):
        if platform.system() == 'Linux':
            self._rowTitlesCanvas.bind_all("<Button-4>", self.on_mouse_wheel)
            self._rowTitlesCanvas.bind_all("<Button-5>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<Button-4>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<Button-5>", self.on_mouse_wheel)

            self._rowTitlesCanvas.bind_all("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self._rowTitlesCanvas.bind_all("<Shift-Button-5>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-Button-5>", self.on_shift_mouse_wheel)
        else:
            self._rowTitlesCanvas.bind_all("<MouseWheel>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

            self._rowTitlesCanvas.bind_all("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-MouseWheel>", self.on_shift_mouse_wheel)

    def _unbind_mousewheel(self, event=None):
        if platform.system() == 'Linux':
            self._rowTitlesCanvas.unbind_all("<Button-4>")
            self._rowTitlesCanvas.unbind_all("<Button-5>")
            self._displayCanvas.unbind_all("<Button-4>")
            self._displayCanvas.unbind_all("<Button-5>")

            self._rowTitlesCanvas.unbind_all("<Shift-Button-4>")
            self._rowTitlesCanvas.unbind_all("<Shift-Button-5>")
            self._displayCanvas.unbind_all("<Shift-Button-4>")
            self._displayCanvas.unbind_all("<Shift-Button-5>")
        else:
            self._rowTitlesCanvas.unbind_all("<MouseWheel>")
            self._displayCanvas.unbind_all("<MouseWheel>")

            self._rowTitlesCanvas.unbind_all("<Shift-MouseWheel>")
            self._displayCanvas.unbind_all("<Shift-MouseWheel>")



class TableManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, model, view, controller, plugin, **kwargs):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._plugin = plugin
        self._kwargs = kwargs
        super().__init__()

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if platform.system() != 'Windows':
            self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        self._ui.register_view(self)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = TableFrame(self)

        if self._mdl.novel is not None:
            self._relationsTable = RelationsTable(self.mainWindow, self._mdl.novel, **self._kwargs)
            self._relationsTable.set_nodes()
        self.isOpen = True
        self.mainWindow.pack(fill='both', expand=True, padx=2, pady=2)

        self._skipUpdate = False
        self.bind('<Control-Button-1>', self.on_element_change)

        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(side='right', padx=5, pady=5)

    def lock(self):
        Node.isLocked = True

    def on_quit(self, event=None):
        self.isOpen = False
        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self.mainWindow.destroy()
        self._ui.unregister_view(self)
        self.destroy()

    def unlock(self):
        Node.isLocked = False

    def refresh(self):
        if self.isOpen:
            if not self._skipUpdate:
                self.mainWindow.pack_forget()
                self.mainWindow.destroy()
                self.mainWindow = TableFrame(self)
                self.mainWindow.pack(fill='both', expand=True, padx=2, pady=2)
                self._relationsTable.draw_matrix(self.mainWindow)
                self._relationsTable.set_nodes()

    def on_element_change(self, event=None):
        self._skipUpdate = True
        self._relationsTable.get_nodes()
        self._skipUpdate = False

SETTINGS = dict(
        window_geometry='600x800',
        color_bg_00='gray80',
        color_bg_01='gray85',
        color_bg_10='gray95',
        color_bg_11='white',
        color_arc_heading='deepSkyBlue',
        color_arc_node='deepSkyBlue3',
        color_character_heading='goldenrod1',
        color_character_node='goldenrod3',
        color_location_heading='coral1',
        color_location_node='coral3',
        color_item_heading='aquamarine1',
        color_item_node='aquamarine3',
)
OPTIONS = {}

APPLICATION = _('Matrix')
PLUGIN = f'{APPLICATION} plugin v4.4.0'


class Plugin(PluginBase):
    VERSION = '4.4.0'
    API_VERSION = '4.5'
    DESCRIPTION = 'A section relationship table'
    URL = 'https://github.com/peter88213/nv_matrix'
    _HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_matrix/'

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')
        self._matrixButton.disable()

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')
        self._matrixButton.enable()

    def install(self, model, view, controller, prefs=None):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            model -- Reference to the model instance of the application.
            view -- Reference to the main view instance of the application.
            controller -- Reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._matrixViewer = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.novx/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/matrix.ini'
        self.configuration = self._mdl.nvService.make_configuration(
            settings=SETTINGS,
            options=OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._start_viewer)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

        self._ui.helpMenu.add_command(label=_('Matrix plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))


        prefs = controller.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None
        try:
            matrixIcon = tk.PhotoImage(file=f'{iconPath}/matrix.png')
        except:
            matrixIcon = None

        tk.Frame(view.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._matrixButton = MatrixButton(view, _('Matrix'), matrixIcon, self._start_viewer)

    def lock(self):
        """Inhibit changes on the model.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')
        self._matrixButton.disable()
        if self._matrixViewer:
            self._matrixViewer.lock()

    def on_close(self):
        """Apply changes and close the window.
        
        Overrides the superclass method.
        """
        self.on_quit()

    def on_quit(self):
        """Actions to be performed when novelibre is closed.
        
        Overrides the superclass method.
        """
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

    def unlock(self):
        """Enable changes on the model.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')
        self._matrixButton.enable()
        if self._matrixViewer:
            self._matrixViewer.unlock()

    def _start_viewer(self):
        if not self._mdl.prjFile:
            return

        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                if self._matrixViewer.state() == 'iconic':
                    self._matrixViewer.state('normal')
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        self._matrixViewer = TableManager(self._mdl, self._ui, self._ctrl, self, **self.kwargs)
        self._matrixViewer.title(f'{self._mdl.novel.title} - {PLUGIN}')
        set_icon(self._matrixViewer, icon='mLogo32', default=False)

